import re
import sys
from pyspark import SparkConf, SparkContext
conf = SparkConf()
sc = SparkContext(conf=conf)

lines = sc.textFile(sys.argv[1])
#parse, remove null ch,filter ch whose first letter is alphabet
words = lines.flatMap(lambda l: re.split(r'[^\w]+', l)).filter(lambda word: word!='').filter(lambda word: word[0].isalpha())
#make lower and remove duplicates
words_lower = words.map(lambda word: word.lower()).distinct()

#generate pairs that takes first letter as keys 
pairs = words_lower.map(lambda word: (word[0], 1))

result = pairs.reduceByKey(lambda n1,n2: n1+n2)

aList =[chr(i) for i in range(97,123)]
for key in result.sortByKey().keys().collect():
    aList.remove(key)
set = []
for key in aList:
    set.append((key,0))
x = sc.parallelize(set)

for (key,value) in result.union(x).sortByKey().collect():
    print(str(key)+'\t'+str(value))